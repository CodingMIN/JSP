package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;

public final class login_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');

	String path = request.getContextPath();
	String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(' ');
  
  request.setCharacterEncoding("utf-8") ;
   //获取用户请求信息，首次请求是没有这些信息的，从页面填写了信息提交后的再次请求就有这些信息了
  String user = request.getParameter("user");
  String password = request.getParameter("password");
  if ("admin".equals(user) && "123".equals(password)) {
    request.getSession().setAttribute("username", user);//将用户名保存在session中
   
      out.write("\r\n");
      out.write("   <!--该URL的基准地址与它所在的JSP页面地址相同，而它所在的JSP的页面基准地址就要看其设置了 -->\r\n");
      out.write("    ");
      if (true) {
        _jspx_page_context.forward("./logok.jsp" + (("./logok.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("info", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("新人乍到，请多关照哦！", request.getCharacterEncoding()));
        return;
      }
      out.write("\r\n");
      out.write("   ");
}
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("  <base href=\"");
      out.print(basePath);
      out.write("\">\r\n");
      out.write("<body><center>\r\n");
      out.write(" <form  action=\"login.jsp\"  method=\"post\">\r\n");
      out.write(" <table>\r\n");
      out.write("  <tr><td colspan=\"2\" align=\"center\">用户登录</td></tr>\r\n");
      out.write("\t  ");
      out.write("\r\n");
      out.write("\t  ");
 if (null != user && null != password) { 
      out.write("\r\n");
      out.write("\t    <tr><td colspan=\"2\">用户名或密码错误，请重新登录！</td></tr>\r\n");
      out.write("\t  ");
}
      out.write("\r\n");
      out.write("\t\t<tr><td>登录名:</td>\r\n");
      out.write("\t\t\t<td><input type=\"text\" name=\"user\"></td></tr>\r\n");
      out.write("\t\t<tr><td>密码 </td>\r\n");
      out.write("\t\t\t<td><input type=\"password\" name=\"password\">\t</td></tr>\r\n");
      out.write("        <tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"登录\"></td></tr>\r\n");
      out.write(" </table>\r\n");
      out.write(" </form> </center>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
